package com.bookshelf.entities;

public enum PaymentMode {

	ONLINE_PAYMENT, CASH_ON_DELIVERY
}
