package com.bookshelf.entities;

public enum Role {

	CUSTOMER,ADMIN
}
