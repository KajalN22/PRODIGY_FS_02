package com.bookshelf.exception;

public class CategoryNotFoundException extends RuntimeException {

	
	public CategoryNotFoundException(String mesg) {
		// TODO Auto-generated constructor stub
		super(mesg);
	}
}
