package com.bookshelf.exception;

public class UnauthorizedException extends RuntimeException {

	public UnauthorizedException(String mesg) {
		// TODO Auto-generated constructor stub
		super(mesg);
	}
}
