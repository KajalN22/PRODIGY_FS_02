package com.bookshelf.exception;

public class ResourceNotFoundException extends RuntimeException{

	public ResourceNotFoundException(String mesg) {
		// TODO Auto-generated constructor stub
		super(mesg);
	}
}
