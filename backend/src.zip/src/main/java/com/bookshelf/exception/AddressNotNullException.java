package com.bookshelf.exception;

public class AddressNotNullException extends Exception {

	public AddressNotNullException(String mesg ) {
		super(mesg);
	}
}
